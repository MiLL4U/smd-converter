from .singlesmdconverter import App

app = App()
app.mainloop()
