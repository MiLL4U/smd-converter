class ApplicationSettings:
    def __init__(self) -> None:
        self.__item1 = 123
